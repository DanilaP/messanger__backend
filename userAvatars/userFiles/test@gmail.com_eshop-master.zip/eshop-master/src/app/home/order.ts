export const orders = [
    {
        "name": "Чай с молоком", 
        "price": 50,
        "calories": 75
    }
]